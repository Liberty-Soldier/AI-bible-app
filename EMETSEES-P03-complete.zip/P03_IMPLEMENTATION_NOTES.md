# EMETSEES P03 — EMET Evidence Packet Compiler

## Files

- `build-evidence-packets.js` — complete deterministic P03 compiler.
- `install-emetsees-p03.ps1` — one-command installer, package-script integration, build, verification, backup, and rollback.

## Install

Place `install-emetsees-p03.ps1` in the `ai-bible-app` repository root, then run:

```powershell
powershell -ExecutionPolicy Bypass -File .\install-emetsees-p03.ps1
```

The installer writes:

```text
scripts/entity/build-evidence-packets.js
```

It adds:

```text
npm run build:evidence-packets
npm run verify:evidence-packets
npm run build:entity-platform
```

`build:entity-platform` becomes:

```text
npm run build:entity && npm run build:knowledge && npm run build:evidence-packets
```

It does not change the Word Study popup or Vercel runtime.

## Inputs

```text
.private/entity/build/P01/entities.json
.private/entity/build/P02/knowledge-index.json
.private/see/build/RelationshipGraph/index.json
.private/see/build/EventGraph/index.json
.private/see/build/ThemeGraph/index.json
```

P01 remains authoritative for lexical, rendering, occurrence, reference, chronology, health, and provenance evidence. P02 contributes only indexed SEE references and statistics. P03 dereferences every P02 pointer to validate it and stores complete pointer lists plus limited deterministic excerpts. It never embeds complete SEE graph objects.

## Outputs

```text
.private/entity/build/P03/evidence-packets.json
.private/entity/build/P03/manifest.json
.private/entity/build/P03/audit.json
```

Every P01 entity receives exactly one packet. Every packet receives its own SHA-256 checksum for future P04 incremental rebuilds.

Availability levels:

- `full-see` — P01 entity evidence plus one or more valid SEE Relationship/Event/Theme references.
- `entity-evidence` — P01 entity evidence exists, but corpus-aware SEE graph references are unavailable.
- `alignment-only` — reserved for a later runtime fallback when an alignment points to no P01 entity; P03 does not intentionally emit these packets.

An LXX entity such as `word:lxx:L703209` remains an independent L-prefixed entity. Its `strong` field is `null`, while its LXX lexical ID is preserved.

## Determinism and verification

The compiler:

- sorts entity IDs;
- uses canonical sorted-key JSON serialization;
- excludes timestamps;
- fingerprints every source file with SHA-256 and byte size;
- checks each packet checksum;
- validates all P02 pointers against SEE;
- validates P01 corpus, occurrence count, and chronology preservation;
- verifies that no complete SEE object was embedded;
- serializes twice during each build;
- compares all three outputs against a prior build when compiler version and input fingerprints are unchanged;
- fails if the rebuild is not byte-identical.

Run verification separately with:

```powershell
npm run verify:evidence-packets
```

## Synthetic validation completed

The supplied compiler was tested with Hebrew, Greek NT, and LXX fixtures and rebuilt twice. All three output files were byte-identical. The test confirmed:

- Hebrew evidence with Relationship/Event/Theme pointers becomes `full-see`.
- Greek NT and LXX evidence without those pointers becomes `entity-evidence`.
- LXX occurrence totals, chronology, Brenton renderings, lexical ID, lemma, and source forms are retained.
- No Strong’s number is manufactured for an L-prefixed LXX entity.
- Full SEE graph-only fields are not copied into packet excerpts.
