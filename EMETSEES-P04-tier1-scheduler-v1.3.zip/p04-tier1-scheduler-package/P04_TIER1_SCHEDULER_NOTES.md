# EMETSEES P04 v1.3 — Tier-Safe Cached EMET Scheduler

## What this completes

P04 v1.3 completes the offline free-tier generation workflow for a Tier 1 OpenAI API project.

It adds:

- a permanent 90–120 word cached EMET explanation contract
- strict word-range validation in generation and final audit
- one entity per Batch API request by default
- deterministic corpus-balanced entity selection
- token-budgeted Batch preparation
- output-token reserves in addition to input-token estimates
- a conservative 1.6 million-token job budget under the user’s 2 million-token daily Tier 1 limit
- a 24-hour local submission cooldown
- resumable prepare, submit, status, import, verify, and retry behavior
- measured input/output usage reporting
- scheduler state and audit artifacts
- a single state-aware command: `npm run emet:generate`

The scheduler does not change the Word Study popup and does not introduce live AI into ordinary word taps.

## Prompt change

The prompt becomes:

```text
emet-free-tier-entity-explanation@1.2.0
```

Every explanation must be complete and contain 90–120 total words. It must still cover:

- source-word identity
- lexical meaning
- Scripture usage
- SEE availability or connections
- the principal evidence limitation

This prompt change intentionally invalidates the earlier 27 test/pilot records. They will be regenerated under the final 90–120 word contract.

## Tier 1 defaults

The installer adds these settings to `.env.local` only when they are missing:

```env
EMET_P04_TIER_DAILY_TOKEN_LIMIT=2000000
EMET_P04_SCHEDULER_TOKEN_BUDGET=1600000
EMET_P04_SCHEDULER_REQUEST_SIZE=1
EMET_P04_SCHEDULER_COOLDOWN_HOURS=24
EMET_P04_OUTPUT_TOKEN_RESERVE=600
```

The effective output reserve automatically rises above 600 when measured P04 usage indicates a larger conservative reserve is needed.

The 400,000-token gap between the configured Tier limit and scheduler budget protects against estimation error, synchronous tests, output tokens, and other API activity.

## Commands

Inspect the final plan without an API request:

```powershell
npm run emet:generate:plan
```

Run the next appropriate scheduler action:

```powershell
npm run emet:generate
```

That one command is state-aware:

- no active job: prepares and submits the next safe job
- prepared job during cooldown: leaves it prepared and prints the next eligible time
- submitted job: refreshes its status
- completed job: imports and verifies it, then prepares the next job
- all entities complete: verifies final P04 artifacts

View current scheduler and Batch status:

```powershell
npm run emet:generate:status
```

Keep the terminal open and poll until the current job finishes:

```powershell
npm run emet:generate:watch
```

Reset only scheduler orchestration state, preserving Batch jobs and generated explanations:

```powershell
npm run emet:generate:reset
```

## Expected first plan

Because the prompt checksum changes from 1.1.0 to 1.2.0, the first plan should show approximately:

```text
Reusable : 0
Pending  : 27206
```

This is expected. P03 is not being rebuilt. The earlier cached explanations remain in state for provenance, but are not reusable under the final word-count contract.

## Daily operation

Run:

```powershell
npm run emet:generate
```

The first invocation prepares and submits a safe Tier 1 job. Later invocations check status, import completed results, retry failures one entity at a time, and prepare the next job. The 24-hour local gate prevents the scheduler from submitting the next full-budget job too soon.

When the API tier changes, update the two limits in `.env.local`. For example, after confirming a larger model-specific daily limit:

```env
EMET_P04_TIER_DAILY_TOKEN_LIMIT=<confirmed limit>
EMET_P04_SCHEDULER_TOKEN_BUDGET=<safe value below that limit>
```

Do not raise the scheduler budget based only on the organization spend limit. Use the model-specific token limit shown in the OpenAI Limits page.

## Output and state

```text
.private/entity/build/P04/generation-state.json
.private/entity/build/P04/scheduler-state.json
.private/entity/build/P04/scheduler-audit.json
.private/entity/build/P04/batch-jobs/<job-id>/
```

Final outputs remain:

```text
.private/entity/build/P04/cached-explanations.json
.private/entity/build/P04/manifest.json
.private/entity/build/P04/audit.json
```

Final artifacts are written only after every current P03 packet has one valid current explanation.

## Validation performed

The implementation passed:

- JavaScript syntax validation
- prompt checksum invalidation of older records
- strict 90–120 word validation
- explicit final-audit word-range invariant
- deterministic corpus-balanced selection
- combined input-plus-output token budgeting
- selection truncation below the configured Tier budget
- one-entity-per-request isolation
- resumable scheduler state
- multi-job prepare/submit/status/import/verify flow
- reversed/unordered Batch output import through `custom_id`
- measured usage aggregation
- next-job preparation after import
- final P04 artifact generation and verification
- preservation of existing Batch jobs and generation state

OpenAI Batch jobs use uploaded JSONL, unique `custom_id` values, the `/v1/responses` endpoint, and a 24-hour completion window. The scheduler retains the existing P04 Batch implementation and adds a conservative local Tier gate around it.
