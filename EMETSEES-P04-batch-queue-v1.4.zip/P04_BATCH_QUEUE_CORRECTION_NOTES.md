# EMETSEES P04 Batch Queue Correction v1.4

## Why this correction exists

P04 v1.3 interpreted the organization’s 2,000,000 TPD standard API limit as
a daily Batch limit. OpenAI Batch uses a separate rate-limit pool.

For GPT-5.6 Luna at Tier 1:

- Batch queue limit: 5,000,000 enqueued prompt tokens
- Output tokens do not count against the Batch queue limit
- Batch does not consume the standard per-model token limit
- Completion window: up to 24 hours, often faster

## Permanent scheduler settings

```env
EMET_P04_BATCH_QUEUE_LIMIT=5000000
EMET_P04_SCHEDULER_INPUT_TOKEN_BUDGET=4500000
EMET_P04_SCHEDULER_COOLDOWN_HOURS=0
EMET_P04_SCHEDULER_REQUEST_SIZE=1
EMET_P04_OUTPUT_TOKEN_RESERVE=600
```

The 4.5M input budget leaves a 500k prompt-token safety margin.

## Behavior

- The existing active Batch job and all cached P04 records are preserved.
- The scheduler budgets only estimated prompt/input tokens against the queue.
- Output-token reserves are still recorded for cost planning but do not reduce
  the Batch queue capacity.
- There is no artificial 24-hour cooldown.
- `npm run emet:generate` imports a completed job and immediately submits the
  next queue-safe job.
- `npm run emet:generate:watch` remains open, polls the active job, imports it,
  prepares and submits the next job, and repeats until P04 is complete.
- One entity remains assigned to each request to prevent collateral validation
  failures.

## Operating command

```powershell
npm run emet:generate:watch
```

Keep the PowerShell window open. If the process or computer stops, run the same
command again; scheduler state, Batch manifests, and accepted records are
resumable.

## Expected throughput

The first v1.3 production job estimated 1,339,981 input tokens for 349 entities.
At a 4.5M prompt-token budget, a similar workload would fit approximately
1,100–1,200 entities per queue cycle. The exact number is recalculated from the
real entity requests and will vary.

This removes the 78-day artificial schedule. Total elapsed time still depends
on OpenAI’s actual Batch turnaround; each Batch has a 24-hour completion window
but often completes sooner.
